module scaffold {
  exports scaffold.api;

  requires org.jooq.jool;
}
