module scaffold {
  exports scaffold.api;

  requires org.jooq.jool;

  uses scaffold.api.ScaffoldPlugin;
}
