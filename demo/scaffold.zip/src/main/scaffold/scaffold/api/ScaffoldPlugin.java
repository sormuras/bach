package scaffold.api;

public interface ScaffoldPlugin {}
