package scaffold;

class ScaffoldMainTests {}
