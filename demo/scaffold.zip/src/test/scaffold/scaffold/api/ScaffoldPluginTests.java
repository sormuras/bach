package scaffold.api;

class ScaffoldPluginTests {}
