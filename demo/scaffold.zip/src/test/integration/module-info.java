open module integration {
  requires scaffold;
  requires org.apiguardian.api;
  requires org.junit.jupiter.api;
}
