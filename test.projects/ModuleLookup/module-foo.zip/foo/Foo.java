package foo;

public class Foo {
  @Override
  public String toString() {
    return "Foo 9";
  }
}
