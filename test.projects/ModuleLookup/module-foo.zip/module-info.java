module foo {
  exports foo;
}
